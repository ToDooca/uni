package xyz.todooc4.university.repository;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import xyz.todooc4.university.entity.ProjectObligation;

@Repository
public interface ProjectObligationRepository extends JpaRepository<ProjectObligation, Integer>, JpaSpecificationExecutor<ProjectObligation> {

}