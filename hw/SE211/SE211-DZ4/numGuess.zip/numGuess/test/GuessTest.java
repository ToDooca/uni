import numGuess.NumGuess;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GuessTest {

    @Test
    public void newGuesser() {
        NumGuess.Guesser g = new NumGuess.Guesser(0, 10);

        assertEquals(0, g.lower);
        assertEquals(10, g.upper);
    }

    @Test
    public void setLowerToOne() {
        NumGuess.Guesser g = new NumGuess.Guesser(0, 10);

        assertEquals(1, g.lower);
        assertEquals(10, g.upper);
    }
}